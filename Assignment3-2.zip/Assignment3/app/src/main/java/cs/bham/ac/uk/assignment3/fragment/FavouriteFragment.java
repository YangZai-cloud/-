package cs.bham.ac.uk.assignment3.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.List;

import cs.bham.ac.uk.assignment3.R;
import cs.bham.ac.uk.assignment3.adapter.FoodAdapter;
import cs.bham.ac.uk.assignment3.object.Food;


public class FavouriteFragment extends Fragment {


    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    RecyclerView recyclerView;
    FoodAdapter foodAdapter;
    List<Food> foodList;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView =  inflater.inflate(R.layout.fragment_favourite, container, false);
        recyclerView = rootView.findViewById(R.id.favorite_recyclerview);
        preferences = getContext().getSharedPreferences("cooking", Context.MODE_PRIVATE);
        editor = preferences.edit();

        String s = preferences.getString("favorite",null);
        if(s==null){
            foodList= new ArrayList<>();
        }else{
            foodList = JSON.parseArray(s, Food.class);
        }
        LinearLayoutManager LayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(LayoutManager);
        foodAdapter = new FoodAdapter(foodList,getContext());
        recyclerView.setAdapter(foodAdapter);
        return rootView;
    }
}
