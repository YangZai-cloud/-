package cs.bham.ac.uk.assignment3.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cs.bham.ac.uk.assignment3.DetailActivity;
import cs.bham.ac.uk.assignment3.R;
import cs.bham.ac.uk.assignment3.object.Food;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    private List<Food> foodList;
    Context context;
    public void setData(List<Food> foodList){
        this.foodList = foodList;
        notifyDataSetChanged();
    }
    public FoodAdapter(List<Food> foodList, Context context) {
        this.foodList = foodList;
        this.context = context;
    }


    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_food,viewGroup,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    @Override
    public int getItemCount() {
        return foodList == null ? 0 : foodList.size();
    }






    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView meal;
        TextView time;
        LinearLayout itemLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            meal = itemView.findViewById(R.id.meal);
            time = itemView.findViewById(R.id.time);
            itemLayout = itemView.findViewById(R.id.itemlayout);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {

        final Food food = foodList.get(i);
        viewHolder.name.setText(food.getName());
        viewHolder.meal.setText(food.getMeal());
        viewHolder.time.setText(food.getTime());
        viewHolder.itemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("food",food);
                context.startActivity(intent);
            }
        });

    }
}

