package cs.bham.ac.uk.assignment3.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSON;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.List;

import cs.bham.ac.uk.assignment3.R;
import cs.bham.ac.uk.assignment3.adapter.FoodAdapter;
import cs.bham.ac.uk.assignment3.object.Food;


public class HomeFragment extends Fragment {

    FoodAdapter foodAdapter;
    RequestQueue foodQueue;
    RecyclerView recyclerView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView =  inflater.inflate(R.layout.fragment_food, container, false);


        recyclerView = rootView.findViewById(R.id.meal_recyclerview);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        foodAdapter = new FoodAdapter(null,getActivity());
        recyclerView.setAdapter(foodAdapter);

        getData();
        return rootView;

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    public void getData(){

         foodQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest("https://www.sjjg.uk/eat/food-items",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String foods) {

                        List<Food> foodList = JSON.parseArray(foods, Food.class);
                        foodAdapter.setData(foodList);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", error.getMessage(), error);
            }
        });

        foodQueue.add(stringRequest);
    }
}
