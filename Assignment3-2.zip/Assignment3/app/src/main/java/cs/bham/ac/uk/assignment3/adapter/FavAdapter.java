package cs.bham.ac.uk.assignment3.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import cs.bham.ac.uk.assignment3.R;

public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {

   
    public FavAdapter(String[] values) {
        this.number = values;
     
    }
    private String[] number;
    @Override
    public void onBindViewHolder(@NonNull FavAdapter.ViewHolder viewHolder, int i) {

        viewHolder.value.setText(number[i]);


    }

    @Override
    public FavAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.content,viewGroup,false);
        FavAdapter.ViewHolder viewHolder = new FavAdapter.ViewHolder(view);
        return viewHolder;
    }



    @Override
    public int getItemCount() {
        return number == null ? 0 : number.length;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView value;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            value = itemView.findViewById(R.id.value);
        }
    }
}

