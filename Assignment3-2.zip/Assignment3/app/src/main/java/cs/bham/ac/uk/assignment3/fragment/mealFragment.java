package cs.bham.ac.uk.assignment3.fragment;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.List;

import cs.bham.ac.uk.assignment3.R;
import cs.bham.ac.uk.assignment3.adapter.FoodAdapter;
import cs.bham.ac.uk.assignment3.object.Food;

/**
 * A simple {@link Fragment} subclass.
 */
public class mealFragment extends Fragment {
    FoodAdapter foodRecyclerViewAdapter;
    RecyclerView recyclerView;
    RequestQueue mQueue;
    TextView ascorder;
    TextView descorder;
    TextView breakfast_pre;
    TextView lunch_pre;
    TextView dinner_pre;
    String order=null;
    String preferValue=null;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;


    public mealFragment() {
        // Required empty public constructor



    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView =  inflater.inflate(R.layout.fragment_meal, container, false);
        preferences = getContext().getSharedPreferences("cooking", Context.MODE_PRIVATE);
        editor = preferences.edit();

        preferValue = preferences.getString("prefer",null);
        order =  preferences.getString("order",null);

        recyclerView = rootView.findViewById(R.id.meal_recyclerview);

        ascorder = rootView.findViewById(R.id.asc);
        descorder = rootView.findViewById(R.id.desc);
        breakfast_pre = rootView.findViewById(R.id.breakfast);
        lunch_pre = rootView.findViewById(R.id.lunch);
        ascorder.setOnClickListener(ascClick);
        descorder.setOnClickListener(descClick);
        dinner_pre = rootView.findViewById(R.id.dinner);
        breakfast_pre.setOnClickListener(breakfastClick);
        lunch_pre.setOnClickListener(lunchClick);
        ascorder = rootView.findViewById(R.id.asc);
        descorder = rootView.findViewById(R.id.desc);
        dinner_pre.setOnClickListener(dinnerClick);


        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        foodRecyclerViewAdapter = new FoodAdapter(null,getActivity());
        recyclerView.setAdapter(foodRecyclerViewAdapter);
        return rootView;

    }


    View.OnClickListener dinnerClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            preferValue = "Dinner";
            editor.putString("prefer",preferValue);
            editor.commit();
            getData(preferValue,order);
        }
    };

    View.OnClickListener ascClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            order = "asc";
            editor.putString("order",order);
            editor.commit();
            getData(preferValue,order);
        }
    };
    View.OnClickListener descClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            order = "desc";
            editor.putString("order",order);
            editor.commit();
            getData(preferValue,order);
        }
    };
    View.OnClickListener lunchClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            preferValue = "Lunch";
            editor.putString("prefer",preferValue);
            editor.commit();
            getData(preferValue,order);
        }
    };

    View.OnClickListener breakfastClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            preferValue = "Breakfast";
            editor.putString("prefer",preferValue);
            editor.commit();
            getData(preferValue,order);
        }
    };

    public void getData(String preferType,String order){
        String url="https://www.sjjg.uk/eat/food-items";
        if(preferType==null){
            if(order==null){
            }else{
                url = url+"/?ording="+order;
            }
        }else{
            if(order==null){
                url = url+"/?prefer="+preferType;
                System.out.println("111111");
            }else{
                url = url+"/?prefer="+preferType+"&ordering="+order;
            }
        }

        mQueue = Volley.newRequestQueue(getActivity());
        StringRequest stringRequest = new StringRequest(url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String foods) {

                        List<Food> foodList = JSON.parseArray(foods, Food.class);
                        foodRecyclerViewAdapter.setData(foodList);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", error.getMessage(), error);
            }
        });

        mQueue.add(stringRequest);
    }
}







