package cs.bham.ac.uk.assignment3.object;

import java.io.Serializable;

public class Food implements Serializable {

    private Integer id;
    private String name;
    private String meal;
    private String time;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMeal() {
        return meal;
    }

    public void setMeal(String meal) {
        this.meal = meal;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    @Override
    public boolean equals(Object obj) {
        if(this == obj){
            return true;
        }
        if(obj == null){
            return false;
        }

        if(obj instanceof Food){
            Food f = (Food) obj;
            if (this.id .equals(f.id) ) {
                return true;
            }
        }

        return false;
    }

}
