package cs.bham.ac.uk.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.List;

import cs.bham.ac.uk.assignment3.adapter.FavAdapter;
import cs.bham.ac.uk.assignment3.object.Food;
import cs.bham.ac.uk.assignment3.object.foodmade;

public class DetailActivity extends AppCompatActivity {

    TextView nametext;
    TextView description;
    RecyclerView ingredientrecyclerview;
    RecyclerView steprecyclerview;
    FavAdapter ingreRecyclerViewAdapter;
    FavAdapter stepRecyclerViewAdapter;
    Button addFavorite;
    List<Food> foodList=null;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        nametext = findViewById(R.id.detail_name);
        description = findViewById(R.id.description);
        addFavorite= findViewById(R.id.add_favorite);
        preferences = getSharedPreferences("cooking", Context.MODE_PRIVATE);
        editor = preferences.edit();
        ingredientrecyclerview = findViewById(R.id.ingredients_recyclerview);
        steprecyclerview = findViewById(R.id.steps_recyclerview);
        Intent intent = getIntent();
        final Food food = (Food)intent.getSerializableExtra("food");
        nametext.setText(food.getName());
        getData(food.getId()+"");
        addFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String favorites = preferences.getString("favorite",null);
                if(favorites==null){
                    foodList = new ArrayList<>();
                    foodList.add(food);
                }else{
                    foodList = JSON.parseArray(favorites,Food.class);
                    if(foodList.contains(food)){
                        foodList.remove(food);
                    } else{
                        foodList.add(food);
                    }
                }
                String str=null;
                if(foodList.size()!=0){
                    str = JSON.toJSONString(foodList);
                }
                editor.putString("favorite",str);
                editor.commit();

            }
        });
    }


    public void getData(String id){


        RequestQueue mQueue = Volley.newRequestQueue(DetailActivity.this);
        StringRequest stringRequest = new StringRequest("https://www.sjjg.uk/eat/recipe-details/"+id,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String detail) {
                        Log.e("Tag",detail);
                        
                        foodmade foodmade = JSON.parseObject(detail, foodmade.class);
                        description.setText(foodmade.getDescription());

                        LinearLayoutManager mLayoutManager = new LinearLayoutManager(DetailActivity.this);
                        ingredientrecyclerview.setLayoutManager(mLayoutManager);
                        ingreRecyclerViewAdapter = new FavAdapter(foodmade.getIngredients());
                        ingredientrecyclerview.setAdapter(ingreRecyclerViewAdapter);

                        LinearLayoutManager mLayoutManager2 = new LinearLayoutManager(DetailActivity.this);
                        steprecyclerview.setLayoutManager(mLayoutManager2);
                        stepRecyclerViewAdapter = new FavAdapter(foodmade.getSteps());
                        steprecyclerview.setAdapter(stepRecyclerViewAdapter);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", error.getMessage(), error);
            }
        });

        mQueue.add(stringRequest);
    }
}
